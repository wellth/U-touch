var annotated =
[
    [ "Geis", "class_geis.html", "class_geis" ],
    [ "GeisDevice", "class_geis_device.html", "class_geis_device" ],
    [ "GeisEvent", "class_geis_event.html", "class_geis_event" ],
    [ "GeisFilter", "class_geis_filter.html", "class_geis_filter" ],
    [ "GeisFrame", "class_geis_frame.html", "class_geis_frame" ],
    [ "GeisGestureAttr", "struct_geis_gesture_attr.html", "struct_geis_gesture_attr" ],
    [ "GeisGestureClass", "class_geis_gesture_class.html", "class_geis_gesture_class" ],
    [ "GeisGestureFuncs", "struct_geis_gesture_funcs.html", "struct_geis_gesture_funcs" ],
    [ "GeisGroup", "class_geis_group.html", "class_geis_group" ],
    [ "GeisGroupSet", "class_geis_group_set.html", "class_geis_group_set" ],
    [ "GeisInputFuncs", "struct_geis_input_funcs.html", "struct_geis_input_funcs" ],
    [ "GeisInstance", "class_geis_instance.html", "class_geis_instance" ],
    [ "GeisRegion", "class_geis_region.html", "class_geis_region" ],
    [ "GeisSubscription", "class_geis_subscription.html", "class_geis_subscription" ],
    [ "GeisTouch", "class_geis_touch.html", "class_geis_touch" ],
    [ "GeisTouchId", "class_geis_touch_id.html", null ],
    [ "GeisTouchSet", "class_geis_touch_set.html", "class_geis_touch_set" ],
    [ "GeisWinInfo", "struct_geis_win_info.html", "struct_geis_win_info" ]
];