var class_geis =
[
    [ "geis_delete", "group__geis__v2__geis.html#gac8d351201dd533e41d235d5921971a9f", null ],
    [ "geis_new", "group__geis__v2__geis.html#ga7adfc03863ad0716118a2e65c6422288", null ]
];