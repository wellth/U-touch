var class_geis_device =
[
    [ "geis_device_attr", "group__geis__v2__device.html#ga09aff11d9194ca467d7c84487288f975", null ],
    [ "geis_device_attr_by_name", "group__geis__v2__device.html#gabaa8e80dd658e6357d0580aa1da8688a", null ],
    [ "geis_device_attr_count", "group__geis__v2__device.html#ga5aa6e28512e5bfaf977cb9e49b33c336", null ],
    [ "geis_device_id", "group__geis__v2__device.html#ga50dc0197231d68f2b8933c6b25ccde17", null ],
    [ "geis_device_name", "group__geis__v2__device.html#gaf8af5a75015b66cce547d0b39dec94c7", null ],
    [ "geis_device_ref", "group__geis__v2__device.html#gaa6733d91cefb7cd5683d702397f2a139", null ],
    [ "geis_device_unref", "group__geis__v2__device.html#gacec95f4cf068bacbaf2e4b932911f543", null ]
];