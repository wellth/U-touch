var class_geis_event =
[
    [ "geis_event_attr", "group__geis__v2__event__control.html#ga610e4f2e283cec68079131bdf6055e48", null ],
    [ "geis_event_attr_by_name", "group__geis__v2__event__control.html#gabb751273c7c3297c692196bdd1b6fb45", null ],
    [ "geis_event_attr_count", "group__geis__v2__event__control.html#gaa08c802d59fb72d0bd924b62206becc3", null ],
    [ "geis_event_delete", "group__geis__v2__event__control.html#ga6a145ff415ea4ab94636286fffd36398", null ],
    [ "geis_event_type", "group__geis__v2__event__control.html#gae54883e4bfedc254cd02ea2c7efaf21d", null ]
];