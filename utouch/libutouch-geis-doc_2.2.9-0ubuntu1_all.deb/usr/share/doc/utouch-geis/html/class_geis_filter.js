var class_geis_filter =
[
    [ "geis_filter_add_term", "group__geis__v2__filter.html#ga7ebde8cc7e2a4f34627e4ef4ad15a2c6", null ],
    [ "geis_filter_clone", "group__geis__v2__filter.html#ga07760a28436bb5ab4c4261a2a91d84dc", null ],
    [ "geis_filter_delete", "group__geis__v2__filter.html#ga2c54f1ea7a127c879f655534555c02c5", null ],
    [ "geis_filter_name", "group__geis__v2__filter.html#ga552ba714bd1a68428df05a0906dc0090", null ],
    [ "geis_filter_new", "group__geis__v2__filter.html#ga52d7bfa7915e2cedd4076a30daad6071", null ]
];