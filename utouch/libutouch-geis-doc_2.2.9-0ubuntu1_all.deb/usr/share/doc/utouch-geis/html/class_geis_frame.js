var class_geis_frame =
[
    [ "geis_frame_attr", "group__geis__v2__gesture.html#ga9901aec758cd97f9ed0e41cba7d52d49", null ],
    [ "geis_frame_attr_by_name", "group__geis__v2__gesture.html#ga1551d50633fa2092cb75f699abb86214", null ],
    [ "geis_frame_attr_count", "group__geis__v2__gesture.html#ga41670bea606da5a02fdfe66105b4996f", null ],
    [ "geis_frame_id", "group__geis__v2__gesture.html#ga8b20f14deaac0df0663977b2640bb18a", null ],
    [ "geis_frame_is_class", "group__geis__v2__gesture.html#gad656ce0e800967d5e532269cb02e2190", null ],
    [ "geis_frame_matrix", "group__geis__v2__gesture.html#gaca55bcf14c1b11d9deab1bbfb2c6d6d8", null ],
    [ "geis_frame_touchid", "group__geis__v2__gesture.html#ga6a8caa03c57147629f2dc0f7b8a0877e", null ],
    [ "geis_frame_touchid_count", "group__geis__v2__gesture.html#ga01d9a3a398647a9d15081fac36e502c5", null ]
];