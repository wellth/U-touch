var class_geis_gesture_class =
[
    [ "geis_gesture_class_attr", "group__geis__v2__class.html#ga0915ee8d6cf11aa83383ea6d79d6d76b", null ],
    [ "geis_gesture_class_attr_count", "group__geis__v2__class.html#ga09dc30a1a2bd5c857688227b67df6e4f", null ],
    [ "geis_gesture_class_id", "group__geis__v2__class.html#gac2f52686ed17c22ad77d74a25631039e", null ],
    [ "geis_gesture_class_name", "group__geis__v2__class.html#gacf5c481755bbfdbd56a93820ed6eda9c", null ],
    [ "geis_gesture_class_ref", "group__geis__v2__class.html#ga9e44686371c3e59c372be2b156b55110", null ],
    [ "geis_gesture_class_unref", "group__geis__v2__class.html#ga7890f6fdf2e72b5e74cc49487588a616", null ]
];