var class_geis_group =
[
    [ "geis_group_frame", "group__geis__v2__gesture.html#ga3709a8bd7efff1cf8b7b4c31f4485cdb", null ],
    [ "geis_group_frame_count", "group__geis__v2__gesture.html#ga85097654b075e1d9ca28503eab3288a2", null ],
    [ "geis_group_id", "group__geis__v2__gesture.html#ga1e1f00fd070bfdbdab78376cd255c931", null ],
    [ "geis_group_reject", "group__geis__v2__gesture.html#ga965cc254542cbeb2d4d453aa2eadd866", null ]
];