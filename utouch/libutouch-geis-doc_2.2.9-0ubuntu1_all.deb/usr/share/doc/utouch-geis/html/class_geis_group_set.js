var class_geis_group_set =
[
    [ "geis_groupset_group", "group__geis__v2__gesture.html#ga07c6d31e6dfde83a845d72b9f6eab2e6", null ],
    [ "geis_groupset_group_count", "group__geis__v2__gesture.html#gab308576912d2aa8920c9064089c8bb46", null ]
];