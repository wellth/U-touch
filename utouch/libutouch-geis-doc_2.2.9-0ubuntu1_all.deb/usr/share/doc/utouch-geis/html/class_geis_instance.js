var class_geis_instance =
[
    [ "geis_finish", "group__geis__meta.html#gabad0f6bc988ae45627d0a29d4e516948", null ],
    [ "geis_init", "group__geis__meta.html#gab4b13d4579249103e8b0be407e414aa3", null ]
];