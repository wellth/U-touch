var class_geis_region =
[
    [ "geis_region_delete", "group__geis__v2__region.html#ga7bf7e0d8f0082d899473c528b9238348", null ],
    [ "geis_region_name", "group__geis__v2__region.html#gac4f85f904cb5feaee0cb42be4248a330", null ],
    [ "geis_region_new", "group__geis__v2__region.html#ga9d9377458468b145bfda5958bd13c621", null ]
];