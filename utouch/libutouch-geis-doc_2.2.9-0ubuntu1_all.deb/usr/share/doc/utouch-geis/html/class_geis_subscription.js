var class_geis_subscription =
[
    [ "geis_subscription_activate", "group__geis__v2__subscription.html#gaf9ab0c59c1848d502fa0041cbe90d8b3", null ],
    [ "geis_subscription_add_filter", "group__geis__v2__subscription.html#ga2dbffb51db39ea96ae4b789920dd5a4c", null ],
    [ "geis_subscription_deactivate", "group__geis__v2__subscription.html#gae3a0957ff2ffc23ab78f1d7a46a706c2", null ],
    [ "geis_subscription_delete", "group__geis__v2__subscription.html#ga4ceccde5ea4fd59171bd0d33b7d50d53", null ],
    [ "geis_subscription_filter_by_name", "group__geis__v2__subscription.html#ga491a8666daf059ade167331106109bc7", null ],
    [ "geis_subscription_id", "group__geis__v2__subscription.html#ga7c8e4df074c2eab90a13d62e4f6f4731", null ],
    [ "geis_subscription_name", "group__geis__v2__subscription.html#ga4cde6a370b64eb6825a1f9578c750825", null ],
    [ "geis_subscription_new", "group__geis__v2__subscription.html#ga35a50b739ff2807107dc8a43296ca020", null ],
    [ "geis_subscription_remove_filter", "group__geis__v2__subscription.html#ga0af874b4e93bb6a2996befdfa683d03b", null ]
];