var class_geis_touch =
[
    [ "geis_touch_attr", "group__geis__v2__gesture.html#gaa1ddd52766710c1912edd434c0648bd8", null ],
    [ "geis_touch_attr_by_name", "group__geis__v2__gesture.html#ga26148b65f0e8b8e9645126b358f23da4", null ],
    [ "geis_touch_attr_count", "group__geis__v2__gesture.html#gaa15acc9117506fc7e30cb3c3b12e0cb7", null ],
    [ "geis_touch_id", "group__geis__v2__gesture.html#ga426ef8311206c025cc752a2d0c83fdc2", null ]
];