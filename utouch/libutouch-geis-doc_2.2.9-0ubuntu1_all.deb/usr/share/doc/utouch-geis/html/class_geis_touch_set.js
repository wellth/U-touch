var class_geis_touch_set =
[
    [ "geis_touchset_touch", "group__geis__v2__gesture.html#ga64de722d0a6344e376622883f9590d64", null ],
    [ "geis_touchset_touch_by_id", "group__geis__v2__gesture.html#ga42fac1e6b0afb36ebd3dece5c4702646", null ],
    [ "geis_touchset_touch_count", "group__geis__v2__gesture.html#ga5ba69a6021b8eb4cb621d5f5c5a9d8dd", null ]
];