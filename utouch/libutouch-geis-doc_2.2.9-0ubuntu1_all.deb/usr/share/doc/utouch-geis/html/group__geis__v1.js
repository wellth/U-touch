var group__geis__v1 =
[
    [ "Gesture Types", "group__geis__v1__gesture__types.html", "group__geis__v1__gesture__types" ],
    [ "Initialization and Cleanup", "group__geis__meta.html", null ],
    [ "Configuration and Control", "group__geis__v1__config.html", null ],
    [ "Input Devices", "group__geis__v1__input.html", null ],
    [ "Gesture Subscription", "group__geis__v1__subscription.html", null ]
];