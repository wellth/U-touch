var group__geis__v1__gesture__types =
[
    [ "Gesture Primitives", "group__geis__v1__gesture__primitives.html", null ],
    [ "Standard Gesture Types", "group__geis__v1__standar__gesture__types.html", null ],
    [ "Vendor Extension Gesture Types", "group__geis__v1__vendor__extensions.html", null ]
];