var group__geis__v2 =
[
    [ "The Geis API Object", "group__geis__v2__geis.html", null ],
    [ "Error Reporting", "group__geis__v2__error.html", null ],
    [ "Configuration", "group__geis__v2__config.html", null ],
    [ "Attributes", "group__geis__v2__attrs.html", null ],
    [ "Event Control", "group__geis__v2__event__control.html", null ],
    [ "Input Devices", "group__geis__v2__device.html", null ],
    [ "Gesture Classes", "group__geis__v2__class.html", null ],
    [ "Gesture Regions", "group__geis__v2__region.html", null ],
    [ "Gesture Filter", "group__geis__v2__filter.html", null ],
    [ "Gesture Subscription", "group__geis__v2__subscription.html", null ],
    [ "Gesture Frames", "group__geis__v2__gesture.html", null ]
];