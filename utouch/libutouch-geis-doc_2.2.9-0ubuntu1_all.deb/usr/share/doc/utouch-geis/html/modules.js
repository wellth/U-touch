var modules =
[
    [ "Common Types and Definitions", "group__geis__common.html", null ],
    [ "The Simplified GEIS Interface", "group__geis__v1.html", "group__geis__v1" ],
    [ "The Advanced GEIS Interface", "group__geis__v2.html", "group__geis__v2" ]
];