var searchData=
[
  ['added',['added',['../struct_geis_input_funcs.html#ac1270b20d34813652229d039bffb881b',1,'GeisInputFuncs::added()'],['../struct_geis_gesture_funcs.html#ac3f2152953203215a5eb62645e9f048c',1,'GeisGestureFuncs::added()']]]
];
