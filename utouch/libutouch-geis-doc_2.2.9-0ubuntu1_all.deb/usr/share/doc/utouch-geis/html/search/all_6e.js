var searchData=
[
  ['name',['name',['../struct_geis_gesture_attr.html#a78216fa47e8a4872d310232c4e40530e',1,'GeisGestureAttr']]]
];
