var searchData=
[
  ['removed',['removed',['../struct_geis_input_funcs.html#a2ad9ed62c53bf1b7bd33e4611a1ed7c8',1,'GeisInputFuncs::removed()'],['../struct_geis_gesture_funcs.html#a2adefbc1dd220528ecf525889cbfaaa0',1,'GeisGestureFuncs::removed()']]]
];
