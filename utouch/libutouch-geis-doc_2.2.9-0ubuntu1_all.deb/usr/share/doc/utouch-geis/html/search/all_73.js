var searchData=
[
  ['start',['start',['../struct_geis_gesture_funcs.html#a06ce684fd46f1e10b86b23b02bae86d6',1,'GeisGestureFuncs']]]
];
