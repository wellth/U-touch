var searchData=
[
  ['type',['type',['../struct_geis_gesture_attr.html#addb3cd9cf30e64d3b28dc4d20e1fe5a6',1,'GeisGestureAttr']]]
];
