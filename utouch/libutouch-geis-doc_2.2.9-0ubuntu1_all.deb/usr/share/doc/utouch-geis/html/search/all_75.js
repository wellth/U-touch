var searchData=
[
  ['update',['update',['../struct_geis_gesture_funcs.html#a7aa8f768bb714724e968e5a73ed197b4',1,'GeisGestureFuncs']]]
];
