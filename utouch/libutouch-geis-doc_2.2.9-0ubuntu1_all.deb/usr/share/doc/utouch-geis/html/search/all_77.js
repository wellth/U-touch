var searchData=
[
  ['win_5finfo',['win_info',['../struct_geis_win_info.html#aed5fd16183e2551157af627a6862cd7a',1,'GeisWinInfo']]],
  ['win_5ftype',['win_type',['../struct_geis_win_info.html#a9b88892d6bbeb43f8cf6d75b8fbe71b2',1,'GeisWinInfo']]]
];
