var searchData=
[
  ['geisattrtype',['GeisAttrType',['../group__geis__common.html#ga217c1877e3daabc569c30625f3db306f',1,'geis.h']]],
  ['geiseventcallback',['GeisEventCallback',['../group__geis__v2__event__control.html#ga84e1904f0d93dd0cdbf8e2cf6eed88ea',1,'geis.h']]],
  ['geisfilterfacility',['GeisFilterFacility',['../group__geis__v2__filter.html#ga3ea4a448c1dc9d78a6e28719035984a3',1,'geis.h']]],
  ['geisfilteroperation',['GeisFilterOperation',['../group__geis__v2__filter.html#ga7a326fa9e1a1db06075886160c1fa91a',1,'geis.h']]],
  ['geisgestureattr',['GeisGestureAttr',['../group__geis__v1__subscription.html#gafb5ac6ba9008fc1025aea6bb5fb96dc2',1,'geis.h']]],
  ['geisgesturecallback',['GeisGestureCallback',['../group__geis__v1__subscription.html#ga26f24308473a842e39e8afa51adb4dfa',1,'geis.h']]],
  ['geisgesturefuncs',['GeisGestureFuncs',['../group__geis__v1__subscription.html#ga664fc9e94d941cdfa5f200fdb62cf93a',1,'geis.h']]],
  ['geisinputcallback',['GeisInputCallback',['../group__geis__v1__input.html#ga60635065ce0e1af35ff298e10d8aa7e0',1,'geis.h']]],
  ['geisinputfuncs',['GeisInputFuncs',['../group__geis__v1__input.html#ga9bc2c727d6eda87a1c19d93cee1a72f5',1,'geis.h']]],
  ['geisstatus',['GeisStatus',['../group__geis__common.html#ga4150c9ee1456bab3c2e7964c34d1d132',1,'geis.h']]]
];
