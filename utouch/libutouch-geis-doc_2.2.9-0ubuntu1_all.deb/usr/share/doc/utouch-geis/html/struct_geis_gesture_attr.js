var struct_geis_gesture_attr =
[
    [ "boolean_val", "struct_geis_gesture_attr.html#ace2228df546ee81938df745946405ee0", null ],
    [ "float_val", "struct_geis_gesture_attr.html#a8408ccdcd1be788b766e2095d38fc435", null ],
    [ "integer_val", "struct_geis_gesture_attr.html#ac5dd44087cdb34e2693291493b219079", null ],
    [ "name", "struct_geis_gesture_attr.html#a78216fa47e8a4872d310232c4e40530e", null ],
    [ "string_val", "struct_geis_gesture_attr.html#adfe7dcb11cbb3588accffd5350ca13e1", null ],
    [ "type", "struct_geis_gesture_attr.html#addb3cd9cf30e64d3b28dc4d20e1fe5a6", null ]
];