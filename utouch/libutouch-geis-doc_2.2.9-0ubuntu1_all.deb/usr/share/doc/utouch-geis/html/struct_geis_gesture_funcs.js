var struct_geis_gesture_funcs =
[
    [ "added", "struct_geis_gesture_funcs.html#ac3f2152953203215a5eb62645e9f048c", null ],
    [ "finish", "struct_geis_gesture_funcs.html#aa9c962db21c4498e7acb373efece8096", null ],
    [ "removed", "struct_geis_gesture_funcs.html#a2adefbc1dd220528ecf525889cbfaaa0", null ],
    [ "start", "struct_geis_gesture_funcs.html#a06ce684fd46f1e10b86b23b02bae86d6", null ],
    [ "update", "struct_geis_gesture_funcs.html#a7aa8f768bb714724e968e5a73ed197b4", null ]
];