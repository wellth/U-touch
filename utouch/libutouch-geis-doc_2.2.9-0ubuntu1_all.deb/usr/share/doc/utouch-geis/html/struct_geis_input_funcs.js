var struct_geis_input_funcs =
[
    [ "added", "struct_geis_input_funcs.html#ac1270b20d34813652229d039bffb881b", null ],
    [ "changed", "struct_geis_input_funcs.html#ad8cf1530c8bfbd53f09977ea9f556237", null ],
    [ "removed", "struct_geis_input_funcs.html#a2ad9ed62c53bf1b7bd33e4611a1ed7c8", null ]
];